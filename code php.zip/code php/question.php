<?php
/**
 * Created by PhpStorm.
 * User: anonymo
 * Date: 17/9/17
 * Time: 10:34 AM
 */
include_once ('connection.php');
session_start();
$id=$_SESSION['adminid'];
$question=$_POST['question'];
$ct=$_POST['constraint'];
$input=$_POST['input'];
$output=$_POST['output'];
if(!isset($id) || !isset($question) || !isset($ct) || !isset($input) || !isset($output)) {
    echo "something went wrong";
}
else {
    try {
        $st=$conn->prepare("insert into questions(adminid,question,const,input,output) VALUES('?','?','?','?','?')");
        $st->bind_param("sssss",$admin,$ques,$const,$inp,$out);
        $admin=$id;
        $ques=stripcslashes(trim($question));
        $const=$ct;
        $inp=$input;
        $out=$output;
        $result=$st->execute();
        if ($result == TRUE) {
            echo "question inserted";
        } else {
            echo "error";
        }
    } catch (Exception $e) {
        echo "error in server" . $e->getMessage();
    } finally {
        $conn->close();
    }
}
?>