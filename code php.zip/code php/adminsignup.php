<?php
/**
 * Created by PhpStorm.
 * User: anonymo
 * Date: 17/9/17
 * Time: 11:10 AM
 */
require 'connection.php';
$adminid=$_POST['adminid'];
$password=$_POST['password'];
$name=$_POST['name'];
if(!isset($adminid) || !isset($password) || !isset($name)) {
    echo "insufficient values";
}
else if(!preg_match("/^[0-9]{8}$/",$adminid)) {
    echo "invalidid";
}
else if(!preg_match("/^[0-9]{8,12}$/",$password)) {
    echo "invalidpassword";
}
else if(!preg_match("/^[a-zA-Z]{5,12}$/",$name)) {
    echo "invalidname";
}
else {
    try {
        $st=$conn->prepare("Insert into admin(adminid,password,name) values ('?','?','?')");
        $st->bind_param("sss",$admin,$pass,$names);
        $admin=stripcslashes(trim($adminid));
        $pass=stripcslashes(trim($password));
        $names=stripcslashes(trim($name));
        $st->execute();
        $result=$st->get_result();
        if ($result == TRUE) {
            $_SESSION['adminid'] = $adminid;
            $_SESSION['name'] = $name;
            header("Location:adminlogin.html");
        } else {
            echo "error";
        }

    } catch (Exception $e) {
        echo "error in server" . $e->getMessage();
    } finally {
        $conn->close();
    }
}
?>