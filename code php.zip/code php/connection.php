<?php
/**
 * Created by PhpStorm.
 * User: anonymo
 * Date: 17/9/17
 * Time: 1:05 AM
 */
$servername = "localhost";
$username = "localhost";
$password = "codeample";
$dbname = "codeample";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>