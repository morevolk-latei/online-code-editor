<?php
/**
 * Created by PhpStorm.
 * User: anonymo
 * Date: 17/9/17
 * Time: 10:47 AM
 */
$agent=$_SERVER['HTTP_USER_AGENT'];
if(empty($agent) || preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i",$agent)){
echo "invalidrequest";
}
else {
    session_start();
    require 'connection.php';
    $adminid = $_POST['adminid'];
    $password = $_POST['password'];
    if (!isset($adminid) || !isset($password)) {
        echo "blank";
    } else if ((!preg_match("/^[0-9]{8}$/", $adminid))) {
        echo "invalid id";
    } else if (!preg_match("/^[0-9a-zA-Z@]{8,}$/", $password)) {
        echo "invalid password";
    } else {
        try {
            $st = $conn->prepare("Select * from admin where adminid=? and password=?");
            $st->bind_param("aa", $admin, md5($pass));
            $admin = stripcslashes(trim($adminid));
            $pass = stripcslashes(trim($password));
            $st->execute();
            $result = $st->get_result();
            $num = $result->num_rows;
            if ($num > 0) {
                while ($row = $result->fetch_assoc()) {
                    $_SESSION['adminid'] = $adminid;
                    $_SESSION['name'] = $row["name"];
                    header("Location:question.html");
                }
            } else {
                echo "Invalid username or password";
            }
        } catch (Exception $e) {
            echo "error in server" . $e->getMessage();
        } finally {
            $conn->close();
        }
    }
}
?>